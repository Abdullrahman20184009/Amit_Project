package Scenario1;

import Base.BaseClass;
import Pages.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class TestLogin extends BaseClass {

    LoginPage loginPage;
    DashBoardPage dashBoardPage;
    LaptopPage laptopPage;
    LaptopI5 laptopI5;
    LaptopI7 laptopI7;
    CartPage cartPage;
    HomePage homePage;

    //Bonus TC1 invaild login

    @Test(priority = 1)
    public void ErorrLogin1() throws InterruptedException {
        homePage = new HomePage(driver);
        loginPage = homePage.goToLoginPage();

        loginPage.clickOnUserNameBoxInLogin("ahmed12344");
        loginPage.clickOnPasswordBox("123444");
        loginPage.clickOnSubmitLogin();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.alertIsPresent());

        //Wrong password pop up
        Alert alert = driver.switchTo().alert();
        String alertText = alert.getText();
        Assert.assertEquals(alertText, "Wrong password.");
        alert.accept();
    }


    @Test(priority = 1)
    public void SuccessLogin() throws InterruptedException{
        homePage = new HomePage(driver);
        loginPage = homePage.goToLoginPage();

        //Inserting username and password to login
        loginPage.clickOnUserNameBoxInLogin("ahmed12344");
        loginPage.clickOnPasswordBox("123");
        loginPage.clickOnSubmitLogin();

        // Wait for welcome message
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement welcomeMessageElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nameofuser")));

        String actualMessage = welcomeMessageElement.getText();
        Assert.assertEquals(actualMessage, "Welcome ahmed12344");
    }

    @Test(priority = 2)
    public void Cart() throws InterruptedException {
        dashBoardPage = new DashBoardPage(driver);

        // Go to Laptop Page
        laptopPage = dashBoardPage.laptopPage();

        // Go to Sony i5 page
        laptopI5 = laptopPage.laptopI5();

        // Add to cart
        laptopI5.clickOnAddToCart();
        String alertText = laptopI5.getSuccessMessage();
        Assert.assertEquals(alertText, "Product added.");


    }
    @Test(priority = 3)
    public void Cart1() throws InterruptedException{
        // Go to Dashboard Laptop Page
        dashBoardPage = new DashBoardPage(driver);
        laptopPage = dashBoardPage.laptopPage();

        // Click on Sony i7 product
        laptopI7 = laptopPage.laptopi7();

        // Add to cart
        laptopI7.clickOnAddToCart();

        // Get success message
        String alertText = laptopI7.getSuccessMessage();

        // Assertion
        Assert.assertEquals(alertText, "Product added.");
        cartPage = laptopI7.clickOnCartLink();
    }

    @Test(priority = 4)
    public void verifyCompletePurchaseFlow() throws InterruptedException{
        laptopI7 = new LaptopI7(driver);
        cartPage = new CartPage(driver);

        laptopI7.clickOnCartLink();
        // Assert total price in Cart but greater than 0
        String actualTotalPrice = cartPage.getProductInCart();
        int totalPrice = Integer.parseInt(actualTotalPrice);
        Assert.assertTrue(totalPrice > 0, "Total price should be greater than 0");

        // Click on Place Order
        cartPage.ClickOnPlaceOrder();

        // Fill form data
        cartPage.clickOnName("Abdulrahman Osama");
        cartPage.clickOnCountry("Egypt");
        cartPage.clickOnCity("Cairo");
        cartPage.clickOnCredit("1234-5678-9012-3456");
        cartPage.clickOnMonth("08");
        cartPage.clickOnYear("2025");

        // Submit the form
        cartPage.clickOnSubmitFourmButton();

        // Verify confirmation message is visible
        cartPage.thankYouMessageAfterPlacingOrder();

        // Click OK button to close the confirmation
        cartPage.clickOnOkButton();
    }

}


















