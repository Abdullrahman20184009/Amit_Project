package Pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class LaptopI5 {
    WebDriver driver;
    WebDriverWait wait;
    public LaptopI5(WebDriver driver) {
        this.driver=driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    //Locators
    private By addToCart = By.cssSelector(".btn.btn-success.btn-lg");
    private By homeButton = By.xpath("//a[contains(text(),'Home')]");


    //Actions

    public void clickOnAddToCart(){
        wait.until(ExpectedConditions.elementToBeClickable(addToCart)).click();
    }
    public String getSuccessMessage() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = driver.switchTo().alert();
        String alertText = alert.getText();
        alert.accept();
        return alertText;
    }
    public void clickOnHomePage(){
        driver.findElement(homeButton).click();
    }

}
