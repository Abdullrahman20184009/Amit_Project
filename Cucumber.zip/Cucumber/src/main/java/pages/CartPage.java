package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CartPage {
    WebDriver driver;
    WebDriverWait wait;

    public CartPage(WebDriver driver) {
        this.driver= driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    //Locators
    private By totalPrice = By.id("totalp");
    private By placeOrder = By.xpath("//button[contains(text(),'Place Order')]");

    //Data Fourm
    private By dataFourm = By.id("name");
    private By countryName = By.id("country");
    private By cityName = By.id("city");
    private By creditCard = By.id("card");
    private By monthOfBirth = By.id("month");
    private By yearOfBirth = By.id("year");
    private By submitFourm = By.xpath("//button[contains(text(),'Purchase')]");
    private By okButton = By.xpath("//button[contains(text(),'OK')]");
    private By confirmOrderMessage = By.xpath("//h2[text()='Thank you for your purchase!']");

    //Actions


    //TotalPrice in the cart
    public String getProductInCart(){
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(totalPrice)).getText();
    }

    //Place order
    public void ClickOnPlaceOrder(){
        wait.until(ExpectedConditions.elementToBeClickable(placeOrder)).click();
    }

    //Data Fourm
    public void clickOnName(String dataName){
        wait.until(ExpectedConditions.elementToBeClickable(dataFourm)).sendKeys(dataName);
    }
    public void clickOnCountry(String country){
        driver.findElement(countryName).sendKeys(country);
    }
    public void clickOnCity(String city){
        driver.findElement(cityName).sendKeys(city);
    }
    public void clickOnCredit(String credit){
        driver.findElement(creditCard).sendKeys(credit);
    }
    public void clickOnMonth(String month){
        driver.findElement(monthOfBirth).sendKeys(month);
    }
    public void clickOnYear(String year){
        driver.findElement(yearOfBirth).sendKeys(year);
    }

    //Submit Fourm
    public void clickOnSubmitFourmButton(){
        wait.until(ExpectedConditions.elementToBeClickable(submitFourm)).click();
    }

    //Confirming the message

    public String thankYouMessageAfterPlacingOrder() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(confirmOrderMessage))
                .getText();
    }
    //Ok button the end of the submition
    public void clickOnOkButton(){
        wait.until(ExpectedConditions.elementToBeClickable(okButton)).click();
    }




}
