package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HomePage {
    WebDriver driver;
    WebDriverWait wait;

public HomePage (WebDriver driver){
    this.driver=driver;
    this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));


}

//Locators


    private By loginButton = By.id("login2");
    private By signUpButton = By.id("signin2");


//Actions

    public LoginPage goToLoginPage() {
        driver.findElement(loginButton).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginusername")));
        return new LoginPage(driver);
    }

    public SignUpPage SignUpPage(){
        driver.findElement(signUpButton).click();
        return new SignUpPage(driver);
    }


}
