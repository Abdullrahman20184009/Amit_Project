package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LaptopPage {
    WebDriver driver;
    WebDriverWait wait;
    public LaptopPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    //Locators

    private By sonyI5= By.xpath("//a[contains(text(), 'Sony vaio i5')]");
    private By sonyI7 = By.xpath("//a[contains(text(), 'Sony vaio i7')]");

    //Actions


    public void clickOnLaptopSonyA5(){
        wait.until(ExpectedConditions.elementToBeClickable(sonyI5)).click();
    }


    public LaptopI5 laptopI5(){
        wait.until(ExpectedConditions.elementToBeClickable(sonyI5)).click();
        return new LaptopI5(driver);
    }


    //Laptop sony i7
    public void clickOnSonyI7(){
        //Product 2 Added
        wait.until(ExpectedConditions.elementToBeClickable(sonyI7)).click();
    }


    public LaptopI7 laptopi7() {
        wait.until(ExpectedConditions.elementToBeClickable(sonyI7)).click();
        return new LaptopI7(driver);
    }








}
