package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class DashBoardPage {
    WebDriver driver;
    WebDriverWait wait;
    public DashBoardPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    //Locators
    private By laptopButton = By.xpath("//a[contains(text(),'Laptops')]");


    //Actions
    public LaptopPage laptopPage(){
        wait.until(ExpectedConditions.elementToBeClickable(laptopButton)).click();
        return new LaptopPage(driver);
    }


}
