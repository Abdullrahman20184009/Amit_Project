package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {
    WebDriver driver;
    WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));


    }

    //vaild Login
    private By loginButton = By.id("login2");
    private By userNameBox = By.id("loginusername");
    private By passwordBox = By.id("loginpassword");
    private By submitLogin = By.xpath("//button[contains(text(),'Log in')]");

    //assert that the same user entered
    private By welcomeMessage = By.id("nameofuser");


    //Actions

    public void openLoginPopup() {
        driver.findElement(loginButton).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(userNameBox));
    }

    public void clickOnUserNameBoxInLogin(String username){

        driver.findElement(userNameBox).sendKeys(username);
    }
    public void clickOnPasswordBox(String password){
        driver.findElement(passwordBox).sendKeys(password);
    }

    //Passed the login cridential
    public void clickOnSubmitLogin(){
        driver.findElement(submitLogin).click();
    }

    //Assert the login successfully
    public String getWelcomeMessage(){
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage)).getText();
    }


    public DashBoardPage submitLoginAndGoToDashboard() {
        driver.findElement(submitLogin).click();
        // Wait until login is successful (welcome message visible)
        wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
        return new DashBoardPage(driver);
    }













}



