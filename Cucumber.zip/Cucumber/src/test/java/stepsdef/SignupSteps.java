package stepsdef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pages.SignUpPage;

import java.util.UUID;

public class SignupSteps {
    WebDriver driver = Hooks.getDriver();
    SignUpPage signUpPage = new SignUpPage(driver);


    @Given("user open home page and click on Sign-up")
    public void user_open_home_page_and_click_on_sign_up() {
        signUpPage.clickOnSignUp();


    }

    @When("Signup with vaild username and password and then click on signup button")
    public void signupWithVaildUsernameAndPasswordAndThenClickOnSignupButton() {
        String uniqueUsername = "user_" + UUID.randomUUID().toString().substring(0, 8);
        String uniquePassword = "pass_" + UUID.randomUUID().toString().substring(0, 8);
        signUpPage.insertUserName(uniqueUsername);
        signUpPage.insertPassword(uniquePassword);
        signUpPage.clickSubmitButton();
    }


    @Then("user is directed to Home page and confirm by the username on top of the right-corner")
    public void userIsDirectedToHomePageAndConfirmByTheUsernameOnTopOfTheRightCorner() {
        signUpPage.getSuccessMessage();
    }
}
