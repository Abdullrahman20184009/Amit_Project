package stepsdef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import pages.*;

public class LoginSteps {
    WebDriver driver = Hooks.getDriver();
    LoginPage loginPage = new LoginPage(driver);
    DashBoardPage dashBoardPage = new DashBoardPage(driver);
    LaptopPage laptopPage = new LaptopPage(driver);
    LaptopI5 laptopI5 = new LaptopI5(driver);
    LaptopI7 laptopI7 = new LaptopI7(driver);
    CartPage cartPage = new CartPage(driver);


    @Given("user open home page and click on login")
    public void user_open_home_page_and_click_on_login() {
        loginPage.openLoginPopup();

    }

    @When("user enter valid username and password and click on login")
    public void userEnterValidUsernameAndPasswordAndClickOnLogin() {
        loginPage.clickOnUserNameBoxInLogin("ahmed12344");
        loginPage.clickOnPasswordBox("123");
        loginPage.clickOnSubmitLogin();
    }

    @Then("User is directed to Home page and confirm by the username on top of the right-corner")
    public void userIsDirectedToHomePageAndConfirmByTheUsernameOnTopOfTheRightCorner() {
        String actualUser = loginPage.getWelcomeMessage();
        Assert.assertEquals(actualUser, "Welcome ahmed12344");
    }

    @When("user clicks on Laptops from the sidebar")
    public void userClicksOnLaptopsFromTheSidebar() {
        dashBoardPage.laptopPage();


    }
    @And("user click on SonyiFive laptop and clicks on Add cart")
    public void userClickOnSonyiFiveLaptopAndClicksOnAddCart(){
        laptopPage.clickOnLaptopSonyA5();
        laptopI5.clickOnAddToCart();
    }

    @Then("a confirming alret should with message product added")
    public void aConfirmingAlretShouldWithMessageProductAdded() {
        String alertMessage = laptopI5.getSuccessMessage();
        Assert.assertTrue(alertMessage.contains("Product added"));
        laptopI5.clickOnHomePage();
    }

    @When("user returns to dashboard page")
    public void userReturnsToDashBoardPage() {
        // ensure Home button is pressed
        laptopI5.clickOnHomePage();
        //ret
        dashBoardPage.laptopPage();
    }

    @And("user select SonyISeven laptop and click on Add cart")
    public void userSelectSonyISevenLaptopAndClickOnAddCart() {
        laptopPage.clickOnSonyI7();
        laptopI7.clickOnAddToCart();
    }

    @Then("confirmation alret should appear with message product added")
    public void confirmatingAlretShouldAppearWithMessageProductAdded() {
        String alertMessage = laptopI7.getSuccessMessage();
        Assert.assertTrue(alertMessage.contains("Product added"));
    }

    @When("user click on Cart button")
    public void userClickOnCartButton() {
        laptopI7.clickOnCartLink();
    }

    @Then("the total amount should be correctly")
    public void theTotalAmountShouldBeCorrectly() {
        cartPage.getProductInCart();
    }

    @And("both product should appears Sony vaio iFive and iSeven and press place order")
    public void bothProductShouldAppearsSonyVaioIFiveAndISevenAndPressPlaceOrder() {
        cartPage.ClickOnPlaceOrder();
    }

    @And("user fills the order form with:")
    public void userFillsTheOrderFormWith() {
        cartPage.clickOnName("Ahmed");
        cartPage.clickOnCountry("Egypt");
        cartPage.clickOnCity("New-Cairo");
        cartPage.clickOnCredit("123");
        cartPage.clickOnMonth("4");
        cartPage.clickOnYear("2018");
    }

    @And("user clicks on Purchase button")
    public void userClicksOnPurchaseButton() {
        cartPage.clickOnSubmitFourmButton();
    }

    @Then("a success message should be displayed: {string}")
    public void aSuccessMessageShouldBeDisplayed(String expectedMessage) {
        String actualMessage = cartPage.thankYouMessageAfterPlacingOrder();
        Assert.assertEquals(actualMessage, expectedMessage);
        cartPage.clickOnOkButton();
    }

}
